#!/usr/bin/env bash

pip3 install -r ./src/requirements.txt
python3 ./src/__main__.py
