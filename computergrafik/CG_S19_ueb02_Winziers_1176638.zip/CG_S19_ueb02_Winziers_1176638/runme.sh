pip install -r requirements.txt
python ./src/__main__.py
